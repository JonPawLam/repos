﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjendomsMaegleren
{
    class KoeberEmne : Saelger
    {
        //feilds
        private double _minStørrelse;
        private double _maxpris;

        //properties
        public double Minstørrelse
        {
            get { return _minStørrelse; }
        }
        
        public double MaxPris
        {
            get { return _maxpris; }
        }

        

        //Construktor
        public KoeberEmne(int id, string name, string adresse, string mobil, string email, double minStørrelse, double maxpris) : base(id, name, adresse, mobil, email)
        {
            _minStørrelse = minStørrelse;
            _maxpris = maxpris;
            
        }


        // Motoder
        
        
        //ToString
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(_minStørrelse)}: {_minStørrelse}, {nameof(_maxpris)}: {_maxpris}, {nameof(Minstørrelse)}: {Minstørrelse}, {nameof(MaxPris)}: {MaxPris}";
        }
    }
}
